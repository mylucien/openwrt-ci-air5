# SoftBank Air 5 OpenWrt 固件编译文件

## 📦 包含文件

本压缩包包含编译 SoftBank Air 5 (IPQ8072A) OpenWrt 固件所需的三个核心文件：

1. **设备树文件**
   - 路径: `target/linux/qualcommax/files/arch/arm64/boot/dts/qcom/ipq8072-softbank-air5.dts`
   - 大小: ~4 KB

2. **设备定义文件**
   - 路径: `target/linux/qualcommax/ipq807x/softbank-air5.mk`
   - 大小: ~0.5 KB

3. **OpenWrt 配置文件**
   - 路径: `configs/softbank-air5.config`
   - 大小: ~5 KB

---

## 🚀 快速开始

### 方法 1: 使用 openwrt-ci 编译（推荐）

```bash
# 1. 解压文件
tar -xzf softbank-air5-firmware-files.tar.gz
cd softbank-air5-firmware-files

# 2. 克隆 openwrt-ci
git clone https://github.com/breeze303/openwrt-ci.git

# 3. 克隆 LiBwrt 源码
git clone --single-branch -b main-nss https://github.com/LiBwrt/openwrt-6.x.git openwrt

# 4. 复制配置文件
cp configs/softbank-air5.config openwrt-ci/configs/

# 5. 复制设备树
cp target/linux/qualcommax/files/arch/arm64/boot/dts/qcom/ipq8072-softbank-air5.dts \
   openwrt/target/linux/qualcommax/files/arch/arm64/boot/dts/qcom/

# 6. 追加设备定义
cat target/linux/qualcommax/ipq807x/softbank-air5.mk >> \
   openwrt/target/linux/qualcommax/ipq807x/base-files.mk

# 7. 编译
cd openwrt-ci
export BUILD_REPO="https://github.com/LiBwrt/openwrt-6.x.git"
export GITHUB_REF_NAME="main-nss"
export BUILD_PROFILE="softbank-air5.config"
./build.sh
```

---

## 📋 文件说明

### 1. ipq8072-softbank-air5.dts

设备树源文件，定义了以下硬件配置：

- ✅ SoC: Qualcomm IPQ8072A
- ✅ 内存: 512MB DDR4
- ✅ SPI Flash: 64MB/128MB
- ✅ GPIO: 9 个 LED + 1 个按钮
- ✅ UART: Console (ttyMSM0) + HSUART (ttyMSM1)
- ✅ SPI: Flash 控制器
- ✅ PCIe: 5G 模块 (SDX55)
- ✅ WiFi: QCA8074V2 (ath11k 驱动)
- ✅ NSS: 自动配置（通过包含 ipq8074-nss.dtsi）

### 2. softbank-air5.mk

设备编译配置，包含：

- 设备名称: SoftBank Air 5
- SoC: ipq8072
- NSS 固件: nss-firmware-ipq807x
- WiFi 固件: ath11k-firmware-ipq8074
- NSS 加密: kmod-qca-nss-crypto

### 3. softbank-air5.config

OpenWrt 编译配置，包含：

- 目标平台: qualcommax/ipq807x
- 内核版本: 6.12
- NSS 驱动: 9 个驱动全启用
- WiFi 固件: IPQ8074 支持
- 5G 模块: QRTR + MHI 支持
- 基础工具: coreutils, ip-full, iperf3
- 网络工具: curl, ddns-go, dns2socks
- 防火墙: nftables, iptables
- LuCI: 完整的 Web 界面

---

## 🔧 文件复制位置

### 复制到 LiBwrt 源码

```bash
# 假设 LiBwrt 源码在 /path/to/openwrt
cp target/linux/qualcommax/files/arch/arm64/boot/dts/qcom/ipq8072-softbank-air5.dts \
   /path/to/openwrt/target/linux/qualcommax/files/arch/arm64/boot/dts/qcom/

cat target/linux/qualcommax/ipq807x/softbank-air5.mk >> \
   /path/to/openwrt/target/linux/qualcommax/ipq807x/base-files.mk
```

### 复制到 openwrt-ci

```bash
# 假设 openwrt-ci 在 /path/to/openwrt-ci
cp configs/softbank-air5.config /path/to/openwrt-ci/configs/
```

---

## 📊 技术规格

| 项目 | 值 |
|------|-----|
| 目标设备 | SoftBank Air 5 (IPQ8072A) |
| 目标内核 | Linux 6.12 |
| 源码仓库 | LiBwrt/openwrt-6.x (main-nss) |
| 编译工具 | openwrt-ci |
| NSS 支持 | 满血支持（9 个驱动） |
| WiFi 驱动 | ath11k |
| 5G 模块 | SDX55 (PCIe + QRTR) |
| SPI Flash | 64MB/128MB |

---

## ⚠️ 重要提示

### 编译要求

- **磁盘空间**: 至少 20GB
- **编译时间**: 首次 2-4 小时
- **网络**: 稳定连接（下载依赖）
- **系统**: Ubuntu 20.04+ 或 Docker

### 安全警告

1. **ART 分区保护**
   - 位置: 0x002A0000, 大小: 256KB
   - 包含 WiFi 校准数据
   - 刷写前必须备份

2. **硬件要求**
   - SPI Flash 必须 64MB 或 128MB
   - 已扩容并复制原厂启动链

---

## 🐛 常见问题

### 问题 1: 编译失败 - 找不到设备定义

**解决方案**:
```bash
# 检查设备定义是否正确添加
grep -r "softbank_air5" /path/to/openwrt/target/linux/qualcommax/ipq807x/
```

### 问题 2: 设备树编译失败

**解决方案**:
```bash
# 验证设备树语法
dtc -I dts -O dtb -o /dev/null \
    /path/to/openwrt/target/linux/qualcommax/files/arch/arm64/boot/dts/qcom/ipq8072-softbank-air5.dts
```

---

## 📞 更多文档

完整文档请访问项目目录：

- [AUTOBUILD_GUIDE.md](docs/AUTOBUILD_GUIDE.md) - 详细编译指南
- [FINAL_FILE_INDEX.md](docs/FINAL_FILE_INDEX.md) - 文件索引
- [INSTALLATION.md](docs/INSTALLATION.md) - 安装和刷写指南
- [TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) - 故障排除

---

## 📝 版本信息

- **版本**: 1.0
- **日期**: 2025-02-09
- **作者**: Coze Coding
- **许可证**: GPL-2.0

---

## ✅ 检查清单

使用前确认：

- [ ] 已解压压缩包
- [ ] 已克隆 openwrt-ci 仓库
- [ ] 已克隆 LiBwrt 源码仓库（main-nss 分支）
- [ ] 磁盘空间充足（至少 20GB）
- [ ] 网络连接稳定

---

**开始编译吧！** 🚀
